Thanks for downloading!
This game is still very unfinished.

To start it, run 'forest.exe'.