WaveClock
Hunter Forsyth

# INSTALLATION
-If you haven't done so already, download and install Rainmeter from rainmeter.net
-Note that this skin was written for Rainmeter 2.5 and compatibility with other versions is not guaranteed. 
-Place this entire folder in your Rainmeter Skins directory, usually under 'My Documents' -> 'Rainmeter' -> 'Skins'
-Load the skin using rainmeter.

# MEDIA PLAYER SUPPORT
-If your music player is not detected edit 'WaveClock.ini' in this folder with a text editor, you'll find instructions inside.