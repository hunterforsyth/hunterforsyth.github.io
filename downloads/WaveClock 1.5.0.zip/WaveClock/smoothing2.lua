function Initialize()
	CacheTimer=0
	Cache=0
	Cache2=0
	Diff=0
	Timer=0.1
	Dir=0.05
	accel=0
end

function Update()
	mCore = SKIN:GetMeasure('CPU2')
	Core = mCore:GetValue()
	if CacheTimer<10 then
		CacheTimer=CacheTimer+1
		Diff=(Cache2-Cache)/10.0
		if accel < 1 then
			accel = CacheTimer*0.1
		elseif accel >=1 then
			accel = 1 / ((CacheTimer-5)*0.1)
		end
	else
		Diff=(Core-Cache)/10.0
		CacheTimer=0
		accel=0
		Cache=Cache2
		Cache2=Core
	end
	if Timer<0.1 then
		Dir=0.05
	elseif Timer>1.5 then
		Dir=-0.05
	end
	Timer=Timer+Dir
	Fcache=Final
	Final=(Cache+(Diff*CacheTimer*accel))+Timer
	return Final
end