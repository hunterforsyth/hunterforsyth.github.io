function Initialize()
	Alpha=0
end

function Update()
	mPosition = SKIN:GetMeasure('MeasurePosition')
	Position = mPosition:GetValue()
	mDuration = SKIN:GetMeasure('MeasureDuration')
	Duration = mDuration:GetValue()
	Rem = Duration - Position

	if Position==0 then
		Alpha=0
	elseif Rem > 2 and Alpha <= 240 then

		Alpha=Alpha+15
	elseif Rem <= 2 and Alpha >= 15 then
		Alpha=Alpha-15
	end

	return Alpha
end