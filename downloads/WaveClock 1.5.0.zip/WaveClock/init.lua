function Initialize()
	Timer = 1600
end

function Update()
	 if Timer>255 then 
	 	Timer=Timer-12 
	 	return 255
	 elseif Timer>12 then
	 	Timer=Timer-12 
	 	return Timer
	 else
	 	return 0
	 end
end