REACTIONLAB 2 VIEWER FOR PEBBLE
(c) 2015 Hunter Forsyth
=================================
To install this, move RL2_Viewer.pbw to your phone and use a file viewer to open it with the Pebble App.

This app is very experimental. It does not yet support colour, and the ReactionLab 2 drawings it renders are very rough looking.

Enjoy!